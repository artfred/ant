from django.db import models
from django.contrib.sites.models import Site


# Create your models here.
class ContactMeModel(models.Model):
    firstname = models.CharField(max_length=250, null=True, blank=True)
    lastname = models.CharField(max_length=250, null=True, blank=True)
    country = models.CharField(max_length=250, null=True, blank=True)
    message = models.TextField()

    sites = models.ManyToManyField(Site)
    def __str__(self):
        return str(self.firstname)
    
