from django.forms import ModelForm
from .models import ContactMeModel

class ContactMeForm(ModelForm):
    class Meta:
        model = ContactMeModel
        fields = "__all__"
        