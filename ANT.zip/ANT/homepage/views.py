from django.shortcuts import render, redirect
from django.http import HttpResponse
from django_tutorial.models import DjangoTutorialModel

from .forms import ContactMeForm
from django.contrib import messages



# Create your views here.
def home(request):
    
    all_dj_tuts = DjangoTutorialModel.objects.all()
    form = ""
    context = {
        'form': form,
        'all_dj_tuts': all_dj_tuts
    }
    return render(request, 'homepage/index.html', context)


def dj_link(request, title):
    dj_link = DjangoTutorialModel.objects.get(title=title)
    form = ""
    context = {
        'form': form,
        'dj_link': dj_link
    }
    return render(request, 'homepage/dj_link.html', context)


def contact_me(request):
    form = ContactMeForm()

    if request.method == "POST":
        form = ContactMeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Successfully Sent!')
            return redirect('contact-me')
    context = {
        'form': form
        }
    return render(request, 'homepage/contact_me.html', context)

