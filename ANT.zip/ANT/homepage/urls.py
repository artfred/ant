from django.urls import path
from . import views 

urlpatterns = [
    path('', views.home, name='home'),
    path('contact-me/', views.contact_me, name='contact-me'),
    path('django-tutorial/<str:title>/', views.dj_link, name='django-link'),
]