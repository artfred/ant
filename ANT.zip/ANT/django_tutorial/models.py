from django.db import models


# Create your models here.
class DjangoTutorialModel(models.Model):
    user = models.CharField(max_length=250, null=True, blank=True)
    title = models.CharField(max_length=500, null=True, blank=True, unique=True)
    content = models.TextField()
    links = models.CharField(max_length=250, null=True, blank=True)
    def __str__(self):
        return str(self.title)
    
