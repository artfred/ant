from django.apps import AppConfig


class DjangoTutorialConfig(AppConfig):
    name = 'django_tutorial'
