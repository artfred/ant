from django.contrib import admin
from .models import DjangoTutorialModel

# Register your models here.
admin.site.register(DjangoTutorialModel)